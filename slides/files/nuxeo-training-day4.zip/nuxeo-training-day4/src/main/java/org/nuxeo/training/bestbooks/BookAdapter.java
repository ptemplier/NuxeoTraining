/*
 * (C) Copyright 2013 Nuxeo SA (http://nuxeo.com/) and contributors.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Lesser General Public License
 * (LGPL) version 2.1 which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/lgpl-2.1.html
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * Contributors:
 *     bchauvin
 */

package org.nuxeo.training.bestbooks;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;

import org.nuxeo.ecm.core.api.ClientException;
import org.nuxeo.ecm.core.api.CoreSession;
import org.nuxeo.ecm.core.api.DocumentModel;
import org.nuxeo.ecm.core.api.model.PropertyException;

/**
 * 
 */
public class BookAdapter {

    protected final DocumentModel doc;

    public BookAdapter(DocumentModel doc) {
        this.doc = doc;
    }

    public void save(CoreSession session) throws ClientException {
        session.saveDocument(doc);
    }

    public String getId() {
        return doc.getId();
    }

    public List<Object> getAuthor() throws PropertyException, ClientException {
        return (List<Object>)doc.getPropertyValue("bkcommon:author");
    }

    public void setAuthor(List<Object> value) throws PropertyException, ClientException {
        doc.setPropertyValue("bkcommon:author", (Serializable)value);
    }

    public Calendar getBorrowedAt() throws PropertyException, ClientException {
        return (Calendar)doc.getPropertyValue("bkcommon:borrowedAt");
    }

    public void setBorrowedAt(Calendar value) throws PropertyException, ClientException {
        doc.setPropertyValue("bkcommon:borrowedAt", value);
    }

    public String getBorrowedBy() throws PropertyException, ClientException {
        return (String)doc.getPropertyValue("bkcommon:borrowedBy");
    }

    public void setBorrowedBy(String value) throws PropertyException, ClientException {
        doc.setPropertyValue("bkcommon:borrowedBy", value);
    }

    public String getCategory() throws PropertyException, ClientException {
        return (String)doc.getPropertyValue("bkcommon:category");
    }

    public void setCategory(String value) throws PropertyException, ClientException {
        doc.setPropertyValue("bkcommon:category", value);
    }

    public String getIsbn() throws PropertyException, ClientException {
        return (String)doc.getPropertyValue("bkcommon:isbn");
    }

    public void setIsbn(String value) throws PropertyException, ClientException {
        doc.setPropertyValue("bkcommon:isbn", value);
    }

    public Calendar getPublicationDate() throws PropertyException, ClientException {
        return (Calendar)doc.getPropertyValue("bkcommon:publicationDate");
    }

    public void setPublicationDate(Calendar value) throws PropertyException, ClientException {
        doc.setPropertyValue("bkcommon:publicationDate", value);
    }

    public Long getRating() throws PropertyException, ClientException {
        return (Long)doc.getPropertyValue("bkcommon:rating");
    }

    public void setRating(Long value) throws PropertyException, ClientException {
        doc.setPropertyValue("bkcommon:rating", value);
    }

    // Life cycle states
    public void toBorrowed() throws ClientException {
        doc.followTransition("to_borrowed");
    }

    public void toInLibrary() throws ClientException {
        doc.followTransition("to_inLibrary");
    }

    public void toDelete() throws ClientException {
        doc.followTransition("delete");
    }

    public void toUndelete() throws ClientException {
        doc.followTransition("undelete");
    }

}
