package org.nuxeo.training.bestbooks.test;

import java.io.Serializable;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.nuxeo.ecm.automation.AutomationService;
import org.nuxeo.ecm.automation.InvalidChainException;
import org.nuxeo.ecm.automation.OperationContext;
import org.nuxeo.ecm.automation.OperationException;
import org.nuxeo.ecm.core.api.ClientException;
import org.nuxeo.ecm.core.api.CoreSession;
import org.nuxeo.ecm.core.api.DocumentModel;
import org.nuxeo.ecm.core.api.model.PropertyException;
import org.nuxeo.ecm.core.test.CoreFeature;
import org.nuxeo.runtime.api.Framework;
import org.nuxeo.runtime.test.runner.Deploy;
import org.nuxeo.runtime.test.runner.Features;
import org.nuxeo.runtime.test.runner.FeaturesRunner;

import com.google.inject.Inject;

@RunWith(FeaturesRunner.class)
@Features(CoreFeature.class)
@Deploy({ TestStudioBundle.BUNDLE_NAME, "org.nuxeo.ecm.automation.core" })
public class TestStudioBundle {
    // Replace bundle name with the symbolic name of your own Studio project
    public static final String BUNDLE_NAME = "studio.extensions.Training_Nuxeo";

    // Replace bundle name with the project id of your own Studio project
    public static final String COMPONENT_NAME = "studio.extensions.training_d4";

    @Inject
    CoreSession documentManager;

    @Test
    public void shouldDeployStudioBundle() {
        Assert.assertNotNull("The Nuxeo studio bundle should be deployed",
                Framework.getRuntime().getComponent(COMPONENT_NAME));
    }

    @Test
    public void shouldHaveAPublicationDate() throws ClientException {
        // Create doc
        DocumentModel docModel = documentManager.createDocumentModel("/",
                "docId", "Book");
        DocumentModel doc = documentManager.createDocument(docModel);

        // At this point the event handler created in studio should have set the
        // publication date already
        Serializable pubDate = doc.getPropertyValue("bkcommon:publicationDate");

        Assert.assertNotNull("Book should have a publication date", pubDate);
    }

    @Test
    public void shouldHaveCorrectTitle() throws PropertyException,
            ClientException {
        // Create doc with correct properties
        String docTitle = "Da Nuxeo code";

        DocumentModel docModel = documentManager.createDocumentModel("/",
                "docId", "Book");
        docModel.setPropertyValue("dc:title", docTitle);
        DocumentModel doc = documentManager.createDocument(docModel);

        // Save doc
        doc = documentManager.saveDocument(doc);
        documentManager.save();

        // Fetch doc and assert
        doc = documentManager.getDocument(doc.getRef());
        Assert.assertEquals("Should have the correct title", docTitle,
                doc.getTitle());
    }

    @Test
    public void shouldBeBorrowedBySomeone() throws InvalidChainException,
            OperationException, Exception {
        // Create doc
        DocumentModel docModel = documentManager.createDocumentModel("/",
                "docId", "Book");
        DocumentModel doc = documentManager.createDocument(docModel);

        // Save doc
        doc = documentManager.saveDocument(doc);
        documentManager.save();

        // Call borrowBook chain
        AutomationService automationService = Framework.getLocalService(AutomationService.class);
        OperationContext ctx = new OperationContext();
        ctx.setCoreSession(documentManager);
        ctx.setInput(doc);
        automationService.run(ctx, "borrowBook");
        
        // Assert
        doc = documentManager.getDocument(doc.getRef());
        String docLCState = doc.getCurrentLifeCycleState();
        String docBorrowedBy = (String) doc.getPropertyValue("bkcommon:borrowedBy");

        Assert.assertEquals("Life cycle state should be borrowed", "borrowed",
                docLCState);
        Assert.assertNotNull("Book should be borrowed by someone",
                docBorrowedBy);
    }
}
