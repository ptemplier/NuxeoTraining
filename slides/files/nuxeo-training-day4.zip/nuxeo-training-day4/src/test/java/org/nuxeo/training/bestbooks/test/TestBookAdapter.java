package org.nuxeo.training.bestbooks.test;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.nuxeo.ecm.core.api.ClientException;
import org.nuxeo.ecm.core.api.CoreSession;
import org.nuxeo.ecm.core.api.DocumentModel;
import org.nuxeo.ecm.core.test.CoreFeature;
import org.nuxeo.runtime.test.runner.Deploy;
import org.nuxeo.runtime.test.runner.Features;
import org.nuxeo.runtime.test.runner.FeaturesRunner;
import org.nuxeo.training.bestbooks.BookAdapter;

import com.google.inject.Inject;

@RunWith(FeaturesRunner.class)
@Features(CoreFeature.class)
@Deploy({
        TestBookAdapter.BUNDLE_NAME,
        "nuxeo-training-day4:/OSGI-INF/extensions/org.nuxeo.training.bestbooks.BookAdapter.xml" })
public class TestBookAdapter {
    // Replace bundle name with the symbolic name of your own Studio project
    public static final String BUNDLE_NAME = "studio.extensions.Training_Nuxeo";

    @Inject
    CoreSession documentManager;

    @Test
    public void testBookAdapter() throws ClientException {
        // Create book
        DocumentModel bookModel = documentManager.createDocumentModel("/",
                "book", "Book");
        DocumentModel book = documentManager.createDocument(bookModel);

        // Call adapter
        BookAdapter bookAdapter = book.getAdapter(BookAdapter.class);

        // Set values
        bookAdapter.setIsbn("12345");
        bookAdapter.toBorrowed();
        
        // Save doc
        bookAdapter.save(documentManager);
        documentManager.save();

        // Assert values
        Assert.assertEquals("Should have the same ISBN", "12345",
                bookAdapter.getIsbn());
        
        String docState = documentManager.getCurrentLifeCycleState(book.getRef());
        Assert.assertEquals("Should be borrowed", "borrowed", docState);
    }
}
